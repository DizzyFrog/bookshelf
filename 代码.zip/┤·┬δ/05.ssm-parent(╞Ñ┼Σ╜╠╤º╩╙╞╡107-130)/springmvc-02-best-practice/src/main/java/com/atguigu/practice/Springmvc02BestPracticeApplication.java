package com.atguigu.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springmvc02BestPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springmvc02BestPracticeApplication.class, args);
	}

}
