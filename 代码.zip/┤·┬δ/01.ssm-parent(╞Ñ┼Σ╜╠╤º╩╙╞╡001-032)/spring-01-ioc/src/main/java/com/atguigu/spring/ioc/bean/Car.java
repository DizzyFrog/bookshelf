package com.atguigu.spring.ioc.bean;



public class Car {
}
