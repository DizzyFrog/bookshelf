package com.atguigu.spring.ioc.controller;

public class HahaController {
}
