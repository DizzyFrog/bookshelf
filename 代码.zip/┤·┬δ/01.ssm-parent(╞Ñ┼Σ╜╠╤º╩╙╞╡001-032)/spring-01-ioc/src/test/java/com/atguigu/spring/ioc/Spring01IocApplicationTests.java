package com.atguigu.spring.ioc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring01IocApplicationTests {

    @Test
    void contextLoads() {
    }

}
