package com.atguigu.springmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springmvc01HelloworldApplicationTests {

    @Test
    void contextLoads() {
    }

}
