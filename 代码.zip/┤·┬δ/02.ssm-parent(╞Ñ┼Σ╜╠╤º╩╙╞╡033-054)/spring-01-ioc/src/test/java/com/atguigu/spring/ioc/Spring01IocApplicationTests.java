package com.atguigu.spring.ioc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest // 测试SpringBoot功能；测试容器功能
class Spring01IocApplicationTests {

    @Test
    void contextLoads() {
    }

}
